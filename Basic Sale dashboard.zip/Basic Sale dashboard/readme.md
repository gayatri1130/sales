# Basic Sales Dashboard

## Overview
This project presents a basic sales dashboard using Excel and Power BI to visualize overall sales performance by region, salesperson, and product.

## Tools Used
- Microsoft Excel
- Power BI

## Dataset
- Sample sales data including columns like: Region, Product, Quantity, Salesperson, Revenue

## Key Features
- Total Sales Calculation
- Region-wise Sales Visualization (Bar/Map)
- Salesperson Performance Comparison
- Product-wise Sales Breakdown (Pie/Table)
- Interactive Filters with Slicers

## Skills Demonstrated
- Data Cleaning in Excel
- Data Import & Modeling in Power BI
- Visual Design using Charts and Slicers
- Publishing Dashboard to Power BI Service

## Dashboard Preview
![Dashboard Screenshot](image/1.png)(image.2.png)

## Download Files
- [Sales_Dataset.xlsx](Sales_Dashboard.xlsx)
- [Sales_Dashboard.pbix](Sales_dashboard.pbix)

## Author
Gayatri | Aspiring Data Analyst